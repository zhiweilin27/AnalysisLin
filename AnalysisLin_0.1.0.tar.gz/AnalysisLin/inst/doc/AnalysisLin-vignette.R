## ----echo=FALSE---------------------------------------------------------------
library(knitr)

## -----------------------------------------------------------------------------
# Create a data frame
df <- data.frame(
  Descriptive_Statistics = c("desc_stat()",""),
  Data_Visualization = c("numeric_plot()", "categoric_plot()"),
  Correlation_Analysis = c("corr_matrix()", "corr_cluster()"),
  Feature_Engineering = c("missing_impute()", "automate_pca()")
)

# Print the table
kable(df)

## -----------------------------------------------------------------------------
install.packages("/Users/zhiweilin/Desktop/My package/AnalysisLin_0.1.0.tar.gz", repos = NULL, type = "source")
library(AnalysisLin)

## -----------------------------------------------------------------------------
data("iris")
data("mtcars")
data("airquality")

## -----------------------------------------------------------------------------
desc_stat(iris)

## -----------------------------------------------------------------------------
desc_stat(mtcars)

## -----------------------------------------------------------------------------
desc_stat(airquality)

## -----------------------------------------------------------------------------
desc_stat(mtcars,kurtosis = F,skewness = F,jarque_test = F)

## -----------------------------------------------------------------------------
numeric_plot(iris)

## -----------------------------------------------------------------------------
numeric_plot(iris,prob=T,dens=T)

## -----------------------------------------------------------------------------
categoric_plot(iris,bar_width = 1)

## ----results = 'hide'---------------------------------------------------------
categoric_plot(iris,bar=F)

## ----results = 'hide'---------------------------------------------------------
categoric_plot(iris,pie=F)

## -----------------------------------------------------------------------------
corr_matrix(mtcars)

## -----------------------------------------------------------------------------
corr_matrix(mtcars,corrplot=T)

## ----results = 'hide'---------------------------------------------------------
corr_matrix(mtcars,type='pearson')
corr_matrix(mtcars,type='spearman')

## -----------------------------------------------------------------------------
corr_cluster(mtcars,type='pearson')

## -----------------------------------------------------------------------------
corr_cluster(mtcars, type='spearman')

## -----------------------------------------------------------------------------
impute_missing(airquality,method='mean')

## ----results = 'hide',message=FALSE-------------------------------------------
impute_missing(airquality,method='mode')
impute_missing(airquality,method='median')
impute_missing(airquality,method='locf')
impute_missing(airquality,method='knn',k=5)

## -----------------------------------------------------------------------------
automate_pca(mtcars,variance_threshold = 0.9)

